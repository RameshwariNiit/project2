package com.niit.controller;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.Principal;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.model.Blog;
import com.niit.model.Message;
import com.niit.model.OutputMessage;
import com.niit.model.User;
import com.niit.service.UserService;

@Controller
public class HomeController
{
	
	@Autowired
	UserService userserivce;

	ModelAndView mv;
	
	@RequestMapping("/")
	public ModelAndView LandPage()
	{
		mv = new ModelAndView("LandingPage");
		return mv;
	}
	
	@RequestMapping("/reg")
	public ModelAndView RegPage()
	{
		mv = new ModelAndView("Registration");
		return mv;
	}
	
	@RequestMapping("/login")
	public ModelAndView LoginP()
	{
		mv = new ModelAndView("LoginPage");
		return mv;
	}
	
	
	@RequestMapping("/register")
	public String createUser(@ModelAttribute("user") User user , Model model,HttpServletRequest request) throws IOException
	{
		
		String filename = null;
	    byte[] bytes;
	    if (!user.getImage().isEmpty()) 
	    {
	    	try {
	            
	            bytes = user.getImage().getBytes();
	            user.setEnabled(true);
	            user.setRole("ROLE_USER");
	    		user.setEnabled(true);
	    		userserivce.saveOrUpdate(user);
	    		System.out.println("Data Inserted");
	            String path = request.getSession().getServletContext().getRealPath("/resources/images/" + user.getUserid() + ".jpg");
	            System.out.println("Path = " + path);
	            System.out.println("File name = " + user.getImage().getOriginalFilename());
	            File f = new File(path);
	            BufferedOutputStream bs = new BufferedOutputStream(new FileOutputStream(f));
	            bs.write(bytes);
	            bs.close();
	            System.out.println("Image uploaded");
	        } catch (Exception ex) {
	            System.out.println(ex.getMessage());
	        }
	            
	    	
	    }
		
					
		
		return "LoginPage";
	
		
	}
	@ModelAttribute("user")
	public  User returnObject()
	{
		return new User();
	}
	

	@RequestMapping("/Chat")
	  public String viewApplication() 
	{
			System.out.println("i am in controller");
	    return "ChatPage";
	  }
	    
	  @MessageMapping("/chat")
	  @SendTo("/topic/message")
	  public OutputMessage sendMessage(Message message) {
	    return new OutputMessage(message, new Date());
	  }
	  
	  @RequestMapping("/home")
	   public ModelAndView HomePageapp()
	  {
		  mv = new  ModelAndView("Home");
		  return mv;
	  }
	  
	  @RequestMapping("/newwall")
	  public ModelAndView WallPageapp(Principal p)
	  {
		 
		  User useractive = userserivce.getUserByName(p.getName());
		 
		   mv = new ModelAndView("wallpage");
		  mv.addObject("user" , useractive);
		  
		  return mv;
	  }
	  
}
